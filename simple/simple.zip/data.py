import os

import numpy as np
from PIL import Image
import pandas as pd

def convert_to_csv():
    labels = []
    imgs = []
    # iterate through all files in the 'flowers' folder and then through all files in the subfolders
    for root, dirs, files in os.walk("../flowers"):
        for file in files:
            if file.endswith("jpg"):
                # open the image
                img = Image.open(os.path.join(root, file))
                #print filename to check if it works
                print(os.path.join(root, file))
                # resize the image
                img = img.resize((64, 64))
                # convert image to numpy array
                img = np.array(img)

                imgs.append(img)
                #add label as first element of the array (label is the name of the subfolder)
                if root[8:] == 'astilbe':
                    labels.append(0)
                elif root[8:] == 'daisy':
                    labels.append(1)
                elif root[8:] == 'dandelion':
                    labels.append(2)
                elif root[8:] == 'rose':
                    labels.append(3)
                elif root[8:] == 'sunflower':
                    labels.append(4)
                else:
                    labels.append(5)


                # add the name of subfolder as first element of the array
    print(imgs)
    # create a dataframe that will use imgs array as data and labels array as indexes
    df = pd.DataFrame(imgs, index=labels)
    # save dataframe to csv file
    df.to_csv("64dataRGB.csv")


def load_data():
    # load data from csv file
    data = pd.read_csv("64dataRGB.csv")
    return data